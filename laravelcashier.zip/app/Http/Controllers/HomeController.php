<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use Stripe\Stripe;
use Stripe\PaymentMethod as StripePaymentMethod;

class HomeController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('auth');
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Contracts\Support\Renderable
     */
    public function index()
    {
        $user = auth()->user();

        return view('home', [
            'paymentMethods' => $user->paymentMethods()
        ]);
    }

    
    
        public function store(){

          try {
                /*
                *   if App/User is in App\Models\User dont forgert in env.file to add:
                *   CASHIER_MODEL=App\Models\User
                */
                $user = $request->user();

                if( $user->stripe_id == null ){
                    $user->createAsStripeCustomer();
                }

                //create  PaymentMethod (need Stripe Package)
                //use Stripe\PaymentMethod as StripePaymentMethod;
                $paymentMethod = StripePaymentMethod::create([
                    'type' => 'card',
                    'card' => [
                        'token' => $request->get('token'),
                      ],
                ]);


                //update the user table with the paymentMethod we create
                $user->updateDefaultPaymentMethod($paymentMethod);

                //can make a  
                //newSubscription('plan_name',stripe(.com)->products->Pricing-plans->Details->id)
                $user->newSubscription('planname', 'Pricing-plans-id')->create($paymentMethod);


                return back()->with('status', 'Successful');
                //return response()->json('Successful', 200);

            } catch (\Exception $ex) {
                return response()->json($ex->getMessage(), 200);
            }
..
        }
    
    
        public function FastStore(){
            
            $user = $request->user();
            
             //without Stripe Package
            
            if( $user->stripe_id == null ){
                $user->createAsStripeCustomer(['source' => $request->get('token')]);
                $user->updateDefaultPaymentMethodFromStripe();
            }
            
            if($user->hasPaymentMethod()){
                 //can make a  
                //newSubscription('plan_name',stripe(.com)->products->Pricing-plans->Details->id)
                $user->newSubscription('planname', 'Pricing-plans-id')
                    ->create($user->paymentMethods()[0]->id);
            }
            
            
        }
    
    
}
    
    
            
            
